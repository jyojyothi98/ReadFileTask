package com.demo.demo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataControllerEx {
	@Autowired
	ResourceLoader resourceLoader;
	
	@GetMapping("/resources")
	public ResponseEntity<String> getResourceInfo() throws IOException {

		Resource result = resourceLoader.getResource("classpath:data");

		String output = "";

		File file = result.getFile();
		output += "Filename: " + file.getName() + " \n  Executable: " + file.canExecute() + "\n Readable: \" + file.canRead()";

		String content = new String(Files.readAllBytes(file.toPath()));

		return new ResponseEntity<>(content,HttpStatus.OK);
	}
}

